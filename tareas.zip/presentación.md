# yomna
## Málaga Capital
###  Sobre mí 
Soy Yomna , tengo 19 años , soy una chica deportista y me gusta mucho aprender sobre informatica . Mi sUEño es ser interpol , por eso este año 2025
estoy cursando  el grado superio de DAM y preparandome por mi parte las oposiciones de Polícia Nacional.
###  Mis comidas favoritas - Pasta 1   -  Arroz con pollo 2   - Patatas fritas 3   
###  Enlace de interés 
[Visita mi página favorita](https://ejemplo.com) 
###  Imagen que me gusta 
![Texto alternativo](https://ruta-de-la-imagen.com/imagen.jpg)